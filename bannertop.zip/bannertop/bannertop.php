<?php
/**
 * @package BannerTop
 */
/*
Plugin Name: BannerTop
Plugin URI:#
Description: Crea slider de banner de manera sencinlla.
Version: 0.1
Requires at least: 5.8
Requires PHP: 5.6.20
Author: Richard Arce
Author URI: https://github.com/pyaeve/
License: GPLv2 or later
Text Domain: bannertop
*/


include('class.banner.metabox.php');
include('class.banner.settings.php');

// Register Custom Post Type
function cl_banners_register() {

	$labels = array(
		'name'                  => _x( 'Banners', 'Post Type General Name', 'cl' ),
		'singular_name'         => _x( 'Banner', 'Post Type Singular Name', 'cl' ),
		'menu_name'             => __( 'Banners', 'cl' ),
		'name_admin_bar'        => __( 'Post Type', 'cl' ),
		'archives'              => __( 'Item Archives', 'cl' ),
		'attributes'            => __( 'Item Attributes', 'cl' ),
		'parent_item_colon'     => __( 'Parent Item:', 'cl' ),
		'all_items'             => __( 'Resumen', 'cl' ),
		'add_new_item'          => __( 'Nuevo Banner', 'cl' ),
		'add_new'               => __( 'Agregar', 'cl' ),
		'new_item'              => __( 'Nuevo Banner', 'cl' ),
		'edit_item'             => __( 'Editar Banner', 'cl' ),
		'update_item'           => __( 'Actualizar Banner', 'cl' ),
		'view_item'             => __( 'Ver Banner', 'cl' ),
		'view_items'            => __( 'Ver todos lops Banners', 'cl' ),
		'search_items'          => __( 'Buscar Banner', 'cl' ),
		'not_found'             => __( 'Not found', 'cl' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'cl' ),
		'featured_image'        => __( 'Imagen del Banner', 'cl' ),
		'set_featured_image'    => __( 'Seccione una Imagen por favor', 'cl' ),
		'remove_featured_image' => __( 'Remover Imagen', 'cl' ),
		'use_featured_image'    => __( 'Usar esta Imagen', 'cl' ),
		'insert_into_item'      => __( 'Insert into item', 'cl' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'cl' ),
		'items_list'            => __( 'Items list', 'cl' ),
		'items_list_navigation' => __( 'Items list navigation', 'cl' ),
		'filter_items_list'     => __( 'Filter items list', 'cl' ),
	);
	$args = array(
		'label'                 => __( 'Banner', 'cl' ),
		'description'           => __( 'Crea Banner de manera facil y rapida con BannerTop', 'cl' ),
		'labels'                => $labels,
		'supports'              => array( 'thumbnail', 'title' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => false,
		'rewrite'               => false,
		'capability_type'       => 'post',
		'show_in_rest'          => true,
		'rest_base'             => 'banners',
		'rest_controller_class' => 'WP_REST_Banners_Controller',
	);
	register_post_type( 'banner', $args );
	if (class_exists('BannerTop_Metabox_Fields')) {
        new BannerTop_Metabox_Fields();
      };
if (class_exists('BannerTop_PageSettings')) {
        new BannerTop_PageSettings();
      };


}

function cl_banners_scripts_register() {
	wp_enqueue_style( 'banner-style', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css' );
	wp_enqueue_style( 'banner-style-theme', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css' );
	wp_enqueue_script('banner-jquery','https://code.jquery.com/jquery-1.12.4.min.js');
	wp_enqueue_script( 'banner-script', 'https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js');
	

}
function cl_banner_js_in_footer() {
    ?>
        <script>
          $(document).ready(function(){
 			 $('.banner-top-container').slick({
   				  dots: true,
   				  arrows: true,
  infinite: true,
  speed: 300,
  autoplay: true,
  slidesToShow: 1,
  adaptiveHeight: true

 			 });
});
        </script>
    <?php
}

// Add Shortcode
function cl_banners_shortcode_register( $atts ) {

	// Attributes
	$atts = shortcode_atts(
		array(
			'autoplay' => '1',
			'duration' => '7',
			'infinite' => '1',
		),
		$atts,
		'bannertop'
	);

	$args = array(  
        'post_type' => 'banner',
        'post_status' => 'publish',
        'posts_per_page' => -1, 
        'orderby' => 'title', 
        'order' => 'ASC',
        
    );

    $loop = new WP_Query( $args ); 
    $html= '<div class="banner-top-container">';
    while ( $loop->have_posts() ) : $loop->the_post(); 
    	$html.= '<div>';
        $featured_img = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()), 'thumbnail' ); 
     	$url_dest= get_post_meta(get_the_ID(),'banner_url_destination');
        $alt_text = get_post_meta(get_post_thumbnail_id(get_the_ID()),'_wp_attachment_image_alt',true);
        ;
        if ( $featured_img ) {
        	if(!empty($url_dest[0])){
        		$html .="<a href='".$url_dest[0]."'>";
				$html.= "<img src='". $featured_img."' class='img img-fluid' width='100%' height='480px' ";
				$html .="alt='".$alt_text."' />";
				$html .="</a>";
        	}else{
        		$html.= "<img src='". $featured_img."' class='img img-fluid' width='100%' height='480px' />";
        	}
          
        }
        $html.= '</div>';
       
    endwhile;
    $html .='</div>';
    return $html;

}





add_action( 'wp_enqueue_scripts', 'cl_banners_scripts_register', true );
add_shortcode( 'bannertop', 'cl_banners_shortcode_register' );
add_action('wp_footer', 'cl_banner_js_in_footer');

add_action( 'init', 'cl_banners_register', 1);
add_action('init','cl_banners_scripts_register',1);
?>